#!/usr/bin/env tarantool

return "2.7.7"
