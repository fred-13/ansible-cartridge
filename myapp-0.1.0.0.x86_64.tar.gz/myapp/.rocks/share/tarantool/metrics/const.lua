return {
    INF = math.huge,
    NAN = math.huge * 0,
}
