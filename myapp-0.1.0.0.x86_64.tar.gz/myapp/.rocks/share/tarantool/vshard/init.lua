return {
    router = require('vshard.router'),
    storage = require('vshard.storage'),
    consts = require('vshard.consts'),
    error = require('vshard.error'),
}
